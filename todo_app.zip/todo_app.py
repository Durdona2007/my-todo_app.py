# Kunlik Reja (To-Do) Dasturi

todos = []  # Bo‘sh ro‘yxat

def show_menu():
    print("\n=== Kunlik Vazifalar Menyusi ===")
    print("1. Vazifa qo‘shish")
    print("2. Vazifalarni ko‘rish")
    print("3. Vazifani tugallangan deb belgilash")
    print("4. Dasturdan chiqish")

def add_task():
    task = input("Yangi vazifani kiriting: ")
    todos.append({"nom": task, "tugadi": False})
    print("✅ Vazifa qo‘shildi!")

def show_tasks():
    if not todos:
        print("🚫 Hozircha hech qanday vazifa yo‘q.")
        return
    print("\n📋 Vazifalar ro‘yxati:")
    for i, task in enumerate(todos):
        status = "✅" if task["tugadi"] else "❌"
        print(f"{i + 1}. {task['nom']} - {status}")

def mark_done():
    show_tasks()
    if not todos:
        return
    try:
        num = int(input("Qaysi vazifa tugadi (raqam): "))
        if 1 <= num <= len(todos):
            todos[num - 1]["tugadi"] = True
            print("🎉 Vazifa tugallandi!")
        else:
            print("⚠️ Noto‘g‘ri raqam!")
    except:
        print("⚠️ Raqam kiriting!")

# Dastur ishlashi
while True:
    show_menu()
    choice = input("Tanlovingiz (1-4): ")

    if choice == '1':
        add_task()
    elif choice == '2':
        show_tasks()
    elif choice == '3':
        mark_done()
    elif choice == '4':
        print("Dastur tugatildi. Xayr!")
        break
    else:
        print("⚠️ Noto‘g‘ri tanlov!") 
